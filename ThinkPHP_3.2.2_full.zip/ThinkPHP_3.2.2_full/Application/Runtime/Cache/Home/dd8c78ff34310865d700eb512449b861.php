<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>jia</title>
</head>
<body>
我是view下的jia下的json页面
</body>
</html>