<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>jia</title>
</head>
<body>
我是view下的jia下的json1页面
<p>val:<?php echo ($val); ?></p>
<?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr><td><?php echo ($vo['username']); ?></td> <td><?php echo ($vo['email']); ?><br></td></tr><?php endforeach; endif; else: echo "" ;endif; ?>
</body>
</html>