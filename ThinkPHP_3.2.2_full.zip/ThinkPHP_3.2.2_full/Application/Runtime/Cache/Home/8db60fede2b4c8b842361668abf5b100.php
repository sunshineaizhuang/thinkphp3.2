<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>zhanshi</title>
</head>
<body>


我是view下的index下的data2页面
</body>
</html>