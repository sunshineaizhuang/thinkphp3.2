<?php
namespace Home\Controller;
use Think\Controller;
class jiaController extends Controller {

	public function index(){
		echo "jia 方法<hr>";
		echo __NAMESPACE__;
	}
     public function json_encodes(){
            $arr = array('a' => 1, 'b' => 2, 'c' => 3, 'd' => 4, 'e' => 5);
   echo json_encode($arr);
   //return $arr;
         }
    	
      public function json1(){
        $model=M('user');
      $data=$model->select();
      //var_dump($data);  
        $this->assign('data',$data);
       

        $val = '233';
        $this->assign('val',$val);

       $this->display();
       }
       
}